export default function HomePage() {
  return <h1 className="text-white text-3xl p-10">This is Home Page</h1>;
}
